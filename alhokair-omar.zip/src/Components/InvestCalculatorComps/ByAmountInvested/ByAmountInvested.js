import React from "react";
import "./ByAmountInvested.css";

function ByAmountInvested() {
  return <div>ByAmountInvested</div>;
}

export default ByAmountInvested;
