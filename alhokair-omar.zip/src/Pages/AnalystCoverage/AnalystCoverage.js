import React from "react";
import "./AnalystCoverage.css";
import AnalystCoverageMainComp from "../../Components/AnalystCoverageComps/AnalystCoverageMainComp/AnalystCoverageMainComp";

function AnalystCoverage() {
      return <div className="analyst-coverage">
            <AnalystCoverageMainComp />
      </div>;
}

export default AnalystCoverage;
